# Christopher Hurth- Assignment A07: Funtions, part D
# 
# 

from my_func import *
print("Part 2: Demonstrate calling each function in the module using the alias. -completed")
print("Part 3: Demonstrate calling each function you imported. \n")

print(resistance(5, .150))

print(voltage(.5, 100))

print(Resistance_Parallel(1000, 100, 24, 1, 1, 10000))

print(current(100, 300))