# Christopher Hurth- Assignment A07: Funtions, part C:



import my_func as ier
print("Part 2:Demonstrate calling each function in the module using the alias.\n")
print(ier.voltage(.5, 150))

print(ier.Resistance_Parallel(1000, 1000, 100, 24, 1, 20000))

print(ier.resistance(150, .5))

print(ier.current(150, 300))